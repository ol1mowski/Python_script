#Skrypt na zmiane tapety na pulpicie
import ctypes

image_path = r'C:\Users\Olim\Desktop\BOT_PUlpit/E.jpg'
ctypes.windll.user32.SystemParametersInfoW(20, 0, image_path, 0)